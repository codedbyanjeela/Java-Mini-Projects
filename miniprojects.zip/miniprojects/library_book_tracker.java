package miniprojects;

import java.util.Scanner;

public class library_book_tracker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Basic arrays to store up to 10 books
        String[] books = new String[10];
        boolean[] isBorrowed = new boolean[10];
        int totalBooks = 0;

        int choice;

        do {
            // Menu
            System.out.println("\n=== Library Book Tracker ===");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Borrow Book");
            System.out.println("4. Return Book");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // clear newline

            if (choice == 1) {
                // Add a book
                if (totalBooks < 10) {
                    System.out.print("Enter book title: ");
                    books[totalBooks] = sc.nextLine();
                    isBorrowed[totalBooks] = false;
                    totalBooks++;
                    System.out.println("✅ Book added.");
                } else {
                    System.out.println("📚 Library is full.");
                }
            } else if (choice == 2) {
                // View all books
                if (totalBooks == 0) {
                    System.out.println("📭 No books added yet.");
                } else {
                    System.out.println("📘 Book List:");
                    for (int i = 0; i < totalBooks; i++) {
                        if (isBorrowed[i]) {
                            System.out.println((i + 1) + ". " + books[i] + " [Borrowed]");
                        } else {
                            System.out.println((i + 1) + ". " + books[i] + " [Available]");
                        }
                    }
                }
            } else if (choice == 3) {
                // Borrow a book
                System.out.print("Enter book number to borrow: ");
                int bookNum = sc.nextInt();
                if (bookNum >= 1 && bookNum <= totalBooks) {
                    if (!isBorrowed[bookNum - 1]) {
                        isBorrowed[bookNum - 1] = true;
                        System.out.println("📗 Book borrowed.");
                    } else {
                        System.out.println("⚠️ Book already borrowed.");
                    }
                } else {
                    System.out.println("❌ Invalid book number.");
                }
            } else if (choice == 4) {
                // Return a book
                System.out.print("Enter book number to return: ");
                int bookNum = sc.nextInt();
                if (bookNum >= 1 && bookNum <= totalBooks) {
                    if (isBorrowed[bookNum - 1]) {
                        isBorrowed[bookNum - 1] = false;
                        System.out.println("✅ Book returned.");
                    } else {
                        System.out.println("⚠️ This book was not borrowed.");
                    }
                } else {
                    System.out.println("❌ Invalid book number.");
                }
            } else if (choice == 5) {
                System.out.println("👋 Exiting the program. Goodbye!");
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
}
