package miniprojects;
import java.util.Scanner;

public class arrays_based_calculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        // Ask how many numbers
        System.out.print("How many numbers do you want to enter? ");
        n = sc.nextInt();

        // Declare and fill the array
        double[] numbers = new double[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = sc.nextDouble();
        }

        // Show operation menu
        System.out.println("\nChoose an operation:");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Average");
        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();

        double result = 0;

        if (choice == 1) {
            // Addition
            for (int i = 1; i < n; i++) {
                result += numbers[i];
            }
            System.out.println("Sum = " + result);

        } else if (choice == 2) {
            // Subtraction
            for (int i = 1; i < n; i++) {
                result -= numbers[i];
            }
            System.out.println("Result after subtraction = " + result);

        } else if (choice == 3) {
            // Multiplication
            result = 1;
            for (int i = 0; i < n; i++) {
                result *= numbers[i];
            }
            System.out.println("Product = " + result);

        } else if (choice == 4) {
            // Average
            double sum = 0;
            for (int i = 0; i < n; i++) {
                sum += numbers[i];
            }
            result = sum / n;
            System.out.println("Average = " + result);

        } else {
            System.out.println("Invalid choice.");
        }

    }
}
