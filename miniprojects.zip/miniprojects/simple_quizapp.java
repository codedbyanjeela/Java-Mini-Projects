package miniprojects;

import java.util.Scanner;

public class simple_quizapp {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        // Step 1: Create question, options, and answers
        String[] questions = {
                "1. What is the capital of India?",
                "2. Which language is used for Android development?",
                "3. Who is known as the father of Java?",
                "4. What is 5 + 3?",
                "5. Which planet is known as the Red Planet?"
        };

        String[][] options = {
                {"A. Delhi", "B. Mumbai", "C. Chennai", "D. Kolkata"},
                {"A. Python", "B. Java", "C. Swift", "D. C++"},
                {"A. James Gosling", "B. Dennis Ritchie", "C. Bjarne Stroustrup", "D. Guido van Rossum"},
                {"A. 6", "B. 7", "C. 8", "D. 9"},
                {"A. Earth", "B. Mars", "C. Venus", "D. Jupiter"}
        };

        char[] answers = {'A', 'B', 'A', 'C', 'B'}; // Correct options

        int score = 0;

        // Step 2: Loop through questions
        for (int i = 0; i < questions.length; i++) {
            System.out.println("\n" + questions[i]);

            // Display options
            for (int j = 0; j < options[i].length; j++) {
                System.out.println(options[i][j]);
            }

            // Take user input
            System.out.print("Your answer (A/B/C/D): ");
            char userAnswer = sc.next().toUpperCase().charAt(0); // Convert to uppercase

            // Step 3: Check answer
            if (userAnswer == answers[i]) {
                System.out.println("✅ Correct!");
                score++;
            } else {
                System.out.println("❌ Wrong! Correct answer: " + answers[i]);
            }
        }

        // Step 4: Show final score
        System.out.println("\n=== Quiz Over ===");
        System.out.println("Your Score: " + score + " out of " + questions.length);

    }
}
