package miniprojects;

import java.util.Scanner;

public class studentrecordsystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Step 1: Ask how many student records to store
        System.out.print("Enter number of students: ");
        int num = sc.nextInt();
        sc.nextLine(); // Clear the buffer after reading int

        // Step 2: Create arrays to store names and marks
        String[] names = new String[num];
        int[] marks = new int[num];

        // Step 3: Input student names and marks
        for (int i = 0; i < num; i++) {
            System.out.print("Enter name of student " + (i + 1) + ": ");
            names[i] = sc.nextLine();  // Read name

            System.out.print("Enter marks of " + names[i] + ": ");
            marks[i] = sc.nextInt();   // Read marks
            sc.nextLine(); // Consume newline
        }

        // Step 4: Ask user to search a student's record
        System.out.print("\nEnter student name to search: ");
        String searchName = sc.nextLine();

        // Step 5: Search logic
        boolean found = false;
        for (int i = 0; i < num; i++) {
            if (names[i].equalsIgnoreCase(searchName)) {
                // If match found, show details
                System.out.println("\nStudent found: " + names[i]);
                System.out.println("Marks: " + marks[i]);

                // Calculate and show grade
                String grade;
                if (marks[i] >= 90) grade = "A+";
                else if (marks[i] >= 80) grade = "A";
                else if (marks[i] >= 70) grade = "B";
                else if (marks[i] >= 60) grade = "C";
                else if (marks[i] >= 50) grade = "D";
                else grade = "F";

                System.out.println("Grade: " + grade);
                found = true;
                break;
            }
        }

        // If student not found
        if (!found) {
            System.out.println("Student not found in records.");
        }
    }
}
