package miniprojects;

import java.util.Scanner;

public class max_min_finder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask how many numbers to input
        System.out.print("How many numbers do you want to enter? ");
        int n = sc.nextInt();

        // Declare array
        int[] numbers = new int[n];

        // Input numbers into array
        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = sc.nextInt();
        }

        // Initialize max and min
        int max = numbers[0];
        int min = numbers[0];

        // Find max and min using loop
        for (int i = 1; i < n; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }

        // Display result
        System.out.println("\nMaximum number is: " + max);
        System.out.println("Minimum number is: " + min);

    }
}
