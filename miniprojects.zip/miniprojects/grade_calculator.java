package miniprojects;

import java.util.Scanner;

public class grade_calculator {
    public static void main(String[] args) {

        System.out.println("enter the number of subjects");
        Scanner sc= new Scanner(System.in);
        int numberOfSubjects= sc.nextInt();
        int[]marks=new int[numberOfSubjects];


        // Variable to store total marks
        int total = 0;

        // Loop to take input for each subject
        for (int i = 0; i <numberOfSubjects;  i++) {
            System.out.print("Enter marks for subject " + (i + 1) + ": "); //HERE (i+1) IS USED JUST FOR BETTER USER DISPLAY

            marks[i] = sc.nextInt(); // Store input in array
            total += marks[i];      // Add to total
        }

        // Calculate average and percentage
        double average = (double) total / numberOfSubjects;
        double percentage = average; // Assuming each subject is out of 100

        // Determine grade based on percentage
        String grade;
        if (percentage >= 90) {
            grade = "A+";
        } else if (percentage >= 80) {
            grade = "A";
        } else if (percentage >= 70) {
            grade = "B";
        } else if (percentage >= 60) {
            grade = "C";
        } else if (percentage >= 50) {
            grade = "D";
        } else {
            grade = "F";
        }

        // Display the result
        System.out.println("\n--- Result ---");
        System.out.println("Total Marks: " + total);
        System.out.printf("Average: %.2f\n", average);
        System.out.printf("Percentage: %.2f%%\n", percentage);
        System.out.println("Grade: " + grade);

        // Close the scanner (good practice)
        sc.close();
    }
}



