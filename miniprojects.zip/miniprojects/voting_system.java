package miniprojects;

import java.util.Scanner;

public class voting_system {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Step 1: Ask how many people to check
        System.out.print("Enter number of people: ");
        int count = sc.nextInt();
        sc.nextLine();  // Clear buffer

        // Step 2: Create arrays to store names and ages
        String[] names = new String[count];
        int[] ages = new int[count];

        // Step 3: Input names and ages
        for (int i = 0; i < count; i++) {
            System.out.print("Enter name of person " + (i + 1) + ": ");
            names[i] = sc.nextLine();

            System.out.print("Enter age of " + names[i] + ": ");
            ages[i] = sc.nextInt();
            sc.nextLine();  // Clear buffer
        }

        // Step 4: Display eligible voters (age >= 18)
        System.out.println("\nEligible voters:");
        boolean found = false;
        for (int i = 0; i < count; i++) {
            if (ages[i] >= 18) {
                System.out.println(names[i]);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No eligible voters found.");
        }

    }
}
