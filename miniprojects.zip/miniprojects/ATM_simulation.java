package miniprojects;

import java.util.Scanner;

public class ATM_simulation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double balance = 10000.0;  // Initial balance
        int pin = 1234;            // Static PIN for simplicity

        // Step 1: Ask for PIN
        System.out.print("Enter your 4-digit ATM PIN: ");
        int enteredPin = sc.nextInt();

        if (enteredPin != pin) {
            System.out.println("Incorrect PIN. Access Denied.");
        } else {
            int choice;

            // Step 2: ATM Menu
            do {
                System.out.println("\n==== ATM Menu ====");
                System.out.println("1. Check Balance");
                System.out.println("2. Deposit");
                System.out.println("3. Withdraw");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("Current Balance: ₹" + balance);
                        break;

                    case 2:
                        System.out.print("Enter amount to deposit: ₹");
                        double deposit = sc.nextDouble();
                        if (deposit > 0) {
                            balance += deposit;
                            System.out.println("₹" + deposit + " deposited successfully.");
                        } else {
                            System.out.println("Invalid deposit amount.");
                        }
                        break;

                    case 3:
                        System.out.print("Enter amount to withdraw: ₹");
                        double withdraw = sc.nextDouble();
                        if (withdraw > 0 && withdraw <= balance) {
                            balance -= withdraw;
                            System.out.println("₹" + withdraw + " withdrawn successfully.");
                        } else {
                            System.out.println("Invalid or insufficient funds.");
                        }
                        break;

                    case 4:
                        System.out.println("Thank you for using the ATM. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice. Please select again.");
                }

            } while (choice != 4);
        }
    }
}
